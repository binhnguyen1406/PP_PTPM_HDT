﻿CREATE TABLE NhaXuatBan (
    NXB CHAR(10) PRIMARY KEY,
    TenNXB NVARCHAR(100),
    DiaChi NVARCHAR(500)
);

CREATE TABLE Sach (
    MaSach CHAR(10) PRIMARY KEY,
    TenSach NVARCHAR(300),
    NXB CHAR(10),
    TenTG NVARCHAR(100),
    NamXB DATETIME,
    GhiChu NVARCHAR(500),
    FOREIGN KEY (NXB) REFERENCES NhaXuatBan(NXB)
);
-- Thêm dữ liệu bảng Nhà xuất bản
INSERT INTO NhaXuatBan VALUES ('001', N'Nhà xuất bản X-men', N'Quang Trung, Hà Nội');
INSERT INTO NhaXuatBan VALUES ('002', N'Khoa học xã hội', N'Trần Phú, Hà Nội');
INSERT INTO NhaXuatBan VALUES ('003', N'Viện văn hóa thể thao', N'Hai Bà Trưng, Hà Nội');

-- Thêm dữ liệu bảng Sách
INSERT INTO Sach VALUES ('1', N'Lập trình C#', '001', N'Nguyễn Lưu', CONVERT(DATETIME, '2022-01-01'), N'Không');
INSERT INTO Sach VALUES ('2', N'Lập trình ASP.NET Core', '002', N'Trọng Khải', CONVERT(DATETIME, '2019-01-01'), N'Không');
INSERT INTO Sach VALUES ('3', N'Lập trình Scratch', '002', N'Bá Trọng', CONVERT(DATETIME, '2022-01-01'), N'Không');

