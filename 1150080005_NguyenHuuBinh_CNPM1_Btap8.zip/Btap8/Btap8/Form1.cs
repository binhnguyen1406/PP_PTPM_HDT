﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Btap8
{
    public partial class Form1 : Form
    {
        string strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;
                          AttachDbFilename=|DataDirectory|\QuanLySach.mdf;
                          Integrated Security=True";
        SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        private void HienThiDanhSach()
        {
            MoKetNoi();
            string sql = "SELECT * FROM NhaXuatBan";
            SqlCommand cmd = new SqlCommand(sql, sqlCon);
            SqlDataReader reader = cmd.ExecuteReader();

            lsvNXB.Items.Clear();
            while (reader.Read())
            {
                string ma = reader["NXB"].ToString();
                string ten = reader["TenNXB"].ToString();
                string diachi = reader["DiaChi"].ToString();

                ListViewItem lvi = new ListViewItem(ma);
                lvi.SubItems.Add(ten);
                lvi.SubItems.Add(diachi);
                lsvNXB.Items.Add(lvi);
            }

            reader.Close();
            DongKetNoi();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDanhSach();
        }

        private void lsvNXB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvNXB.SelectedItems.Count == 0) return;

            ListViewItem lvi = lsvNXB.SelectedItems[0];
            txtMaNXB.Text = lvi.SubItems[0].Text;
            txtTenNXB.Text = lvi.SubItems[1].Text;
            txtDiaChi.Text = lvi.SubItems[2].Text;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (txtMaNXB.Text == "" || txtTenNXB.Text == "" || txtDiaChi.Text == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return;
            }

            MoKetNoi();
            string sql = "INSERT INTO NhaXuatBan VALUES (@ma, @ten, @diachi)";
            SqlCommand cmd = new SqlCommand(sql, sqlCon);
            cmd.Parameters.AddWithValue("@ma", txtMaNXB.Text.Trim());
            cmd.Parameters.AddWithValue("@ten", txtTenNXB.Text.Trim());
            cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.Trim());

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("✅ Thêm thành công!");
                HienThiDanhSach();
                txtMaNXB.Clear();
                txtTenNXB.Clear();
                txtDiaChi.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm: " + ex.Message);
            }
            DongKetNoi();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (txtMaNXB.Text == "")
            {
                MessageBox.Show("Hãy chọn một nhà xuất bản để sửa!");
                return;
            }

            MoKetNoi();
            string sql = "UPDATE NhaXuatBan SET TenNXB=@ten, DiaChi=@diachi WHERE NXB=@ma";
            SqlCommand cmd = new SqlCommand(sql, sqlCon);
            cmd.Parameters.AddWithValue("@ma", txtMaNXB.Text.Trim());
            cmd.Parameters.AddWithValue("@ten", txtTenNXB.Text.Trim());
            cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.Trim());

            try
            {
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    MessageBox.Show("✏️ Sửa thành công!");
                    HienThiDanhSach();
                }
                else
                {
                    MessageBox.Show("❌ Không tìm thấy Mã NXB để sửa!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa: " + ex.Message);
            }
            DongKetNoi();
        }

        // 🔹 Nút Xóa
        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (txtMaNXB.Text == "")
            {
                MessageBox.Show("Hãy chọn một nhà xuất bản để xóa!");
                return;
            }

            if (MessageBox.Show("Bạn có chắc muốn xóa NXB này?", "Xác nhận xóa",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MoKetNoi();
                string sql = "DELETE FROM NhaXuatBan WHERE NXB=@ma";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@ma", txtMaNXB.Text.Trim());

                try
                {
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("🗑️ Xóa thành công!");
                        HienThiDanhSach();
                        txtMaNXB.Clear();
                        txtTenNXB.Clear();
                        txtDiaChi.Clear();
                    }
                    else
                    {
                        MessageBox.Show("❌ Không tìm thấy Mã NXB để xóa!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi xóa: " + ex.Message);
                }

                DongKetNoi();
            }
        }
    }
}
