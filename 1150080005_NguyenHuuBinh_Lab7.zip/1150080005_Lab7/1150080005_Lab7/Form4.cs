﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _1150080005_Lab7
{
    public partial class Form4 : Form
    {
        // 🔹 Chuỗi kết nối SQL Server của bạn
        string strCon = @"Data Source=LAPTOP-J64LDBSP\SQL2022;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True";

        SqlConnection sqlCon = null;

        public Form4()
        {
            InitializeComponent();
        }

        // ======== MỞ / ĐÓNG KẾT NỐI ========
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ======== HIỂN THỊ DỮ LIỆU ========
        private void HienThiDuLieu()
        {
            try
            {
                MoKetNoi();
                string sql = "SELECT * FROM NhaXuatBan";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();

                lsvNXB.Items.Clear();
                while (reader.Read())
                {
                    ListViewItem lvi = new ListViewItem(reader["MaXB"].ToString());
                    lvi.SubItems.Add(reader["TenNXB"].ToString());
                    lvi.SubItems.Add(reader["DiaChi"].ToString());
                    lsvNXB.Items.Add(lvi);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Lỗi hiển thị dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // ======== FORM LOAD ========
        private void Form4_Load(object sender, EventArgs e)
        {
            lsvNXB.View = View.Details;
            lsvNXB.FullRowSelect = true;
            lsvNXB.GridLines = true;
            lsvNXB.Columns.Add("Mã NXB", 100);
            lsvNXB.Columns.Add("Tên NXB", 200);
            lsvNXB.Columns.Add("Địa chỉ", 250);

            HienThiDuLieu();
        }

        // ======== NÚT XÓA ========
        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (lsvNXB.SelectedItems.Count == 0)
            {
                MessageBox.Show("⚠️ Vui lòng chọn một nhà xuất bản để xóa!");
                return;
            }

            string ma = lsvNXB.SelectedItems[0].SubItems[0].Text;

            DialogResult result = MessageBox.Show(
                "Bạn có chắc muốn xóa NXB có mã '" + ma + "'?",
                "Xác nhận xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    MoKetNoi();
                    string sql = "DELETE FROM NhaXuatBan WHERE MaXB = @ma";
                    SqlCommand cmd = new SqlCommand(sql, sqlCon);
                    cmd.Parameters.AddWithValue("@ma", ma);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("✅ Xóa dữ liệu thành công!");
                        HienThiDuLieu();
                    }
                    else
                    {
                        MessageBox.Show("❌ Không tìm thấy mã NXB cần xóa!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("❌ Lỗi khi xóa: " + ex.Message);
                }
                finally
                {
                    DongKetNoi();
                }
            }
        }
    }
}
