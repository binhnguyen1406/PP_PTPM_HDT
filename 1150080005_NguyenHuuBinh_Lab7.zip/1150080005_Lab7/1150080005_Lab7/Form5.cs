﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _1150080005_Lab7
{
    public partial class Form5 : Form
    {
        // 🔹 Chuỗi kết nối CSDL
        string strCon = @"Data Source=LAPTOP-J64LDBSP\SQL2022;
                          Initial Catalog=QLBanHang;
                          Integrated Security=True";

        SqlConnection sqlCon = null;

        public Form5()
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.Form5_Load); // GẮN SỰ KIỆN LOAD
        }

        // ==========================================================
        // 🔹 HÀM KẾT NỐI / ĐÓNG KẾT NỐI
        // ==========================================================
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ==========================================================
        // 🔹 HIỂN THỊ DỮ LIỆU
        // ==========================================================
        private void HienThiMatHang()
        {
            try
            {
                MoKetNoi();
                string sql = "SELECT * FROM tblMatHang";
                SqlDataAdapter da = new SqlDataAdapter(sql, sqlCon);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvMatHang.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị Mặt hàng: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void HienThiNhaCungCap()
        {
            try
            {
                MoKetNoi();
                string sql = "SELECT * FROM tblNhaCC";
                SqlDataAdapter da = new SqlDataAdapter(sql, sqlCon);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvNCC.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị Nhà cung cấp: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void HienThiHangNhap()
        {
            try
            {
                MoKetNoi();
                string sql = "SELECT * FROM tblHangNhap";
                SqlDataAdapter da = new SqlDataAdapter(sql, sqlCon);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvHN.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị Hàng nhập: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        // ==========================================================
        // 🔹 MẶT HÀNG - CRUD
        // ==========================================================
        private void btnShowSP_Click(object sender, EventArgs e) => HienThiMatHang();

        private void btnAddSP_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = @"INSERT INTO tblMatHang 
                              VALUES (@MaSP, @TenSP, @NgaySX, @NgayHH, @DonVi, @DonGia, @GhiChu)";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSP", txtMaSP.Text.Trim());
                cmd.Parameters.AddWithValue("@TenSP", txtTenSP.Text.Trim());
                cmd.Parameters.AddWithValue("@NgaySX", dtpNSX.Value);
                cmd.Parameters.AddWithValue("@NgayHH", dtpNHH.Value);
                cmd.Parameters.AddWithValue("@DonVi", txtDonVi.Text.Trim());
                cmd.Parameters.AddWithValue("@DonGia", txtDonGia.Text.Trim());
                cmd.Parameters.AddWithValue("@GhiChu", txtGhiChu.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("✅ Thêm sản phẩm thành công!");
                HienThiMatHang();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm sản phẩm: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void btnEditSP_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = @"UPDATE tblMatHang 
                               SET TenSP=@TenSP, NgaySX=@NgaySX, NgayHH=@NgayHH, DonVi=@DonVi, DonGia=@DonGia, GhiChu=@GhiChu 
                               WHERE MaSP=@MaSP";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSP", txtMaSP.Text.Trim());
                cmd.Parameters.AddWithValue("@TenSP", txtTenSP.Text.Trim());
                cmd.Parameters.AddWithValue("@NgaySX", dtpNSX.Value);
                cmd.Parameters.AddWithValue("@NgayHH", dtpNHH.Value);
                cmd.Parameters.AddWithValue("@DonVi", txtDonVi.Text.Trim());
                cmd.Parameters.AddWithValue("@DonGia", txtDonGia.Text.Trim());
                cmd.Parameters.AddWithValue("@GhiChu", txtGhiChu.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("✏️ Sửa sản phẩm thành công!");
                HienThiMatHang();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa sản phẩm: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void btnDeleteSP_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "DELETE FROM tblMatHang WHERE MaSP=@MaSP";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSP", txtMaSP.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("🗑️ Xóa sản phẩm thành công!");
                HienThiMatHang();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa sản phẩm: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        // ==========================================================
        // 🔹 NHÀ CUNG CẤP - CRUD
        // ==========================================================
        private void btnShowNCC_Click(object sender, EventArgs e) => HienThiNhaCungCap();

        private void btnAddNCC_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = @"INSERT INTO tblNhaCC 
                              VALUES (@MaNCC, @TenNCC, @DiaChi, @MaSoThue, @TaiKhoan, @DienThoai)";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaNCC", txtMaNCC.Text.Trim());
                cmd.Parameters.AddWithValue("@TenNCC", txtTenNCC.Text.Trim());
                cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text.Trim());
                cmd.Parameters.AddWithValue("@MaSoThue", txtMST.Text.Trim());
                cmd.Parameters.AddWithValue("@TaiKhoan", txtTK.Text.Trim());
                cmd.Parameters.AddWithValue("@DienThoai", txtDT.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("✅ Thêm nhà cung cấp thành công!");
                HienThiNhaCungCap();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm NCC: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void btnEditNCC_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = @"UPDATE tblNhaCC 
                               SET TenNhaCC=@TenNCC, DiaChi=@DiaChi, MaSoThue=@MaSoThue, TaiKhoan=@TaiKhoan, DienThoai=@DienThoai
                               WHERE MaNhaCC=@MaNCC";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaNCC", txtMaNCC.Text.Trim());
                cmd.Parameters.AddWithValue("@TenNCC", txtTenNCC.Text.Trim());
                cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text.Trim());
                cmd.Parameters.AddWithValue("@MaSoThue", txtMST.Text.Trim());
                cmd.Parameters.AddWithValue("@TaiKhoan", txtTK.Text.Trim());
                cmd.Parameters.AddWithValue("@DienThoai", txtDT.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("✏️ Sửa nhà cung cấp thành công!");
                HienThiNhaCungCap();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa NCC: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void btnDeleteNCC_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "DELETE FROM tblNhaCC WHERE MaNhaCC=@MaNCC";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaNCC", txtMaNCC.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("🗑️ Xóa NCC thành công!");
                HienThiNhaCungCap();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa NCC: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        // ==========================================================
        // 🔹 HÀNG NHẬP - CRUD
        // ==========================================================
        private void btnShowHN_Click(object sender, EventArgs e) => HienThiHangNhap();

        private void btnAddHN_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = @"INSERT INTO tblHangNhap VALUES
                              (@MaSP, @MaNCC, @SoLuong, @DonGia, @SoHD, @NgayGH)";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSP", txtMaSPHN.Text.Trim());
                cmd.Parameters.AddWithValue("@MaNCC", txtMaNCCHN.Text.Trim());
                cmd.Parameters.AddWithValue("@SoLuong", txtSL.Text.Trim());
                cmd.Parameters.AddWithValue("@DonGia", txtDGNH.Text.Trim());
                cmd.Parameters.AddWithValue("@SoHD", txtSoHD.Text.Trim());
                cmd.Parameters.AddWithValue("@NgayGH", dtpNgayGH.Value);
                cmd.ExecuteNonQuery();
                MessageBox.Show("✅ Thêm hàng nhập thành công!");
                HienThiHangNhap();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm hàng nhập: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void btnEditHN_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = @"UPDATE tblHangNhap SET SoLuong=@SoLuong, DonGia=@DonGia, NgayGH=@NgayGH
                               WHERE MaSP=@MaSP AND MaNhaCC=@MaNCC AND SoHD=@SoHD";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSP", txtMaSPHN.Text.Trim());
                cmd.Parameters.AddWithValue("@MaNCC", txtMaNCCHN.Text.Trim());
                cmd.Parameters.AddWithValue("@SoHD", txtSoHD.Text.Trim());
                cmd.Parameters.AddWithValue("@SoLuong", txtSL.Text.Trim());
                cmd.Parameters.AddWithValue("@DonGia", txtDGNH.Text.Trim());
                cmd.Parameters.AddWithValue("@NgayGH", dtpNgayGH.Value);
                cmd.ExecuteNonQuery();
                MessageBox.Show("✏️ Sửa hàng nhập thành công!");
                HienThiHangNhap();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa hàng nhập: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void btnDeleteHN_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "DELETE FROM tblHangNhap WHERE MaSP=@MaSP AND MaNhaCC=@MaNCC AND SoHD=@SoHD";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSP", txtMaSPHN.Text.Trim());
                cmd.Parameters.AddWithValue("@MaNCC", txtMaNCCHN.Text.Trim());
                cmd.Parameters.AddWithValue("@SoHD", txtSoHD.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("🗑️ Xóa hàng nhập thành công!");
                HienThiHangNhap();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa hàng nhập: " + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        // ==========================================================
        // 🔹 LOAD FORM
        // ==========================================================
        private void Form5_Load(object sender, EventArgs e)
        {
            HienThiMatHang();
            HienThiNhaCungCap();
            HienThiHangNhap();
        }
    }
}
