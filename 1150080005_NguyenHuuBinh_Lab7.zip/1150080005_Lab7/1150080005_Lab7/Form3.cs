﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _1150080005_Lab7
{
    public partial class Form3 : Form
    {
        // 🔹 Chuỗi kết nối SQL Server của bạn
        string strCon = @"Data Source=LAPTOP-J64LDBSP\SQL2022;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True";

        SqlConnection sqlCon = null;

        public Form3()
        {
            InitializeComponent();
        }

        // ======== KẾT NỐI DATABASE ========
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ======== HIỂN THỊ DỮ LIỆU ========
        private void HienThiDuLieu()
        {
            try
            {
                MoKetNoi();
                string sql = "SELECT * FROM NhaXuatBan";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();

                lsvNXB.Items.Clear();
                while (reader.Read())
                {
                    ListViewItem lvi = new ListViewItem(reader["MaXB"].ToString());
                    lvi.SubItems.Add(reader["TenNXB"].ToString());
                    lvi.SubItems.Add(reader["DiaChi"].ToString());
                    lsvNXB.Items.Add(lvi);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Lỗi hiển thị dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // ======== FORM LOAD ========
        private void Form3_Load(object sender, EventArgs e)
        {
            lsvNXB.View = View.Details;
            lsvNXB.FullRowSelect = true;
            lsvNXB.GridLines = true;
            lsvNXB.Columns.Add("Mã NXB", 100);
            lsvNXB.Columns.Add("Tên NXB", 200);
            lsvNXB.Columns.Add("Địa chỉ", 250);

            HienThiDuLieu();
        }

        // ======== CHỌN DÒNG TRONG LISTVIEW ========
        private void lsvNXB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvNXB.SelectedItems.Count > 0)
            {
                ListViewItem lvi = lsvNXB.SelectedItems[0];
                txtMaNXB.Text = lvi.SubItems[0].Text;
                txtTenNXB.Text = lvi.SubItems[1].Text;
                txtDiaChi.Text = lvi.SubItems[2].Text;
            }
        }

        // ======== NÚT CHỈNH SỬA ========
        private void btnSua_Click(object sender, EventArgs e)
        {
            if (txtMaNXB.Text == "")
            {
                MessageBox.Show("⚠️ Vui lòng chọn nhà xuất bản để sửa!");
                return;
            }

            try
            {
                MoKetNoi();
                string sql = "UPDATE NhaXuatBan SET TenNXB=@ten, DiaChi=@diachi WHERE MaXB=@ma";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@ma", txtMaNXB.Text.Trim());
                cmd.Parameters.AddWithValue("@ten", txtTenNXB.Text.Trim());
                cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.Trim());

                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    MessageBox.Show("✅ Cập nhật thành công!");
                    HienThiDuLieu();
                }
                else
                {
                    MessageBox.Show("❌ Không tìm thấy Mã NXB để sửa!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Lỗi khi sửa dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}
