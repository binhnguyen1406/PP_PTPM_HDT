﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _1150080005_Lab7
{
    public partial class Form1 : Form
    {
        string strCon = @"Data Source=LAPTOP-J64LDBSP\SQL2022;
                  Initial Catalog=QuanLyBanSach;
                  Integrated Security=True";

        SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        // === Hàm mở kết nối ===
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);

            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // === Hàm đóng kết nối ===
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // === Nút "Hiển thị danh sách" ===
        private void btnHienThi_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "SELECT * FROM NhaXuatBan";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, sqlCon);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "NhaXuatBan");
                dgvDanhSach.DataSource = ds.Tables["NhaXuatBan"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}
