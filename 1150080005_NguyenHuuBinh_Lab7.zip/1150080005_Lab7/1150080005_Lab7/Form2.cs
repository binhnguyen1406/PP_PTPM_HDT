﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _1150080005_Lab7
{
    public partial class Form2 : Form
    {
        // 🔹 Chuỗi kết nối (SQL Server instance của bạn)
        string strCon = @"Data Source=LAPTOP-J64LDBSP\SQL2022;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True";

        SqlConnection sqlCon = null;

        public Form2()
        {
            InitializeComponent();
        }

        // ===== MỞ / ĐÓNG KẾT NỐI =====
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ===== HIỂN THỊ DỮ LIỆU =====
        private void HienThiDuLieu()
        {
            try
            {
                MoKetNoi();
                string sql = "SELECT * FROM NhaXuatBan";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();

                lsvNXB.Items.Clear();
                while (reader.Read())
                {
                    ListViewItem lvi = new ListViewItem(reader["MaXB"].ToString());
                    lvi.SubItems.Add(reader["TenNXB"].ToString());
                    lvi.SubItems.Add(reader["DiaChi"].ToString());
                    lsvNXB.Items.Add(lvi);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Lỗi hiển thị dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // ===== FORM LOAD =====
        private void Form2_Load(object sender, EventArgs e)
        {
            // Cấu hình ListView
            lsvNXB.View = View.Details;
            lsvNXB.FullRowSelect = true;
            lsvNXB.GridLines = true;

            lsvNXB.Columns.Add("Mã NXB", 100);
            lsvNXB.Columns.Add("Tên NXB", 200);
            lsvNXB.Columns.Add("Địa chỉ", 250);

            // Hiển thị dữ liệu ban đầu
            HienThiDuLieu();
        }

        // ===== NÚT "THÊM DỮ LIỆU" =====
        private void btnThem_Click(object sender, EventArgs e)
        {
            if (txtMaNXB.Text == "" || txtTenNXB.Text == "" || txtDiaChi.Text == "")
            {
                MessageBox.Show("⚠️ Vui lòng nhập đầy đủ thông tin!");
                return;
            }

            try
            {
                MoKetNoi();
                string sql = "INSERT INTO NhaXuatBan (MaXB, TenNXB, DiaChi) VALUES (@ma, @ten, @diachi)";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@ma", txtMaNXB.Text.Trim());
                cmd.Parameters.AddWithValue("@ten", txtTenNXB.Text.Trim());
                cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.Trim());

                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    MessageBox.Show("✅ Thêm dữ liệu thành công!");
                    txtMaNXB.Clear();
                    txtTenNXB.Clear();
                    txtDiaChi.Clear();
                    HienThiDuLieu();
                }
                else
                {
                    MessageBox.Show("❌ Thêm dữ liệu thất bại!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Lỗi khi thêm dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}
