﻿using System.Windows.Forms;

namespace _1150080005_Lab7
{
    partial class Form5
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabMatHang;
        private System.Windows.Forms.TabPage tabNhaCC;
        private System.Windows.Forms.TabPage tabHangNhap;

        // Mặt hàng
        private System.Windows.Forms.DataGridView dgvMatHang;
        private System.Windows.Forms.TextBox txtMaSP, txtTenSP, txtDonVi, txtDonGia, txtGhiChu;
        private System.Windows.Forms.DateTimePicker dtpNSX, dtpNHH;
        private System.Windows.Forms.Button btnShowSP, btnAddSP, btnEditSP, btnDeleteSP;

        // Nhà cung cấp
        private System.Windows.Forms.DataGridView dgvNCC;
        private System.Windows.Forms.TextBox txtMaNCC, txtTenNCC, txtDiaChi, txtMST, txtTK, txtDT;
        private System.Windows.Forms.Button btnShowNCC, btnAddNCC, btnEditNCC, btnDeleteNCC;

        // Hàng nhập
        private System.Windows.Forms.DataGridView dgvHN;
        private System.Windows.Forms.TextBox txtMaSPHN, txtMaNCCHN, txtSL, txtDGNH, txtSoHD;
        private System.Windows.Forms.DateTimePicker dtpNgayGH;
        private System.Windows.Forms.Button btnShowHN, btnAddHN, btnEditHN, btnDeleteHN;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabMatHang = new System.Windows.Forms.TabPage();
            this.tabNhaCC = new System.Windows.Forms.TabPage();
            this.tabHangNhap = new System.Windows.Forms.TabPage();

            // =============================
            // FORM
            // =============================
            this.SuspendLayout();
            this.Text = "Quản lý QLBanHang";
            this.ClientSize = new System.Drawing.Size(1000, 600);

            // =============================
            // TABCONTROL
            // =============================
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Controls.Add(this.tabMatHang);
            this.tabControl1.Controls.Add(this.tabNhaCC);
            this.tabControl1.Controls.Add(this.tabHangNhap);
            this.Controls.Add(this.tabControl1);

            // =============================
            // TAB 1 - MẶT HÀNG
            // =============================
            this.tabMatHang.Text = "Mặt hàng";
            Label lblMaSP = new Label() { Text = "Mã SP:", Location = new System.Drawing.Point(20, 20) };
            Label lblTenSP = new Label() { Text = "Tên SP:", Location = new System.Drawing.Point(180, 20) };
            Label lblNgaySX = new Label() { Text = "Ngày SX:", Location = new System.Drawing.Point(350, 20) };
            Label lblNgayHH = new Label() { Text = "Ngày HH:", Location = new System.Drawing.Point(530, 20) };
            Label lblDonVi = new Label() { Text = "Đơn vị:", Location = new System.Drawing.Point(710, 20) };
            Label lblDonGia = new Label() { Text = "Đơn giá:", Location = new System.Drawing.Point(30, 60) };
            Label lblGhiChu = new Label() { Text = "Ghi chú:", Location = new System.Drawing.Point(230, 60) };

            txtMaSP = new TextBox() { Location = new System.Drawing.Point(70, 20), Width = 100 };
            txtTenSP = new TextBox() { Location = new System.Drawing.Point(230, 20), Width = 100 };
            dtpNSX = new DateTimePicker() { Location = new System.Drawing.Point(420, 20), Width = 100 };
            dtpNHH = new DateTimePicker() { Location = new System.Drawing.Point(600, 20), Width = 100 };
            txtDonVi = new TextBox() { Location = new System.Drawing.Point(760, 20), Width = 80 };
            txtDonGia = new TextBox() { Location = new System.Drawing.Point(90, 60), Width = 100 };
            txtGhiChu = new TextBox() { Location = new System.Drawing.Point(290, 60), Width = 550 };

            btnShowSP = new Button() { Text = "Hiển thị", Location = new System.Drawing.Point(860, 20) };
            btnAddSP = new Button() { Text = "Thêm", Location = new System.Drawing.Point(860, 60) };
            btnEditSP = new Button() { Text = "Sửa", Location = new System.Drawing.Point(860, 100) };
            btnDeleteSP = new Button() { Text = "Xóa", Location = new System.Drawing.Point(860, 140) };

            dgvMatHang = new DataGridView()
            {
                Location = new System.Drawing.Point(20, 200),
                Size = new System.Drawing.Size(940, 350),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            tabMatHang.Controls.AddRange(new Control[]
            {
                lblMaSP, lblTenSP, lblNgaySX, lblNgayHH, lblDonVi, lblDonGia, lblGhiChu,
                txtMaSP, txtTenSP, dtpNSX, dtpNHH, txtDonVi, txtDonGia, txtGhiChu,
                btnShowSP, btnAddSP, btnEditSP, btnDeleteSP, dgvMatHang
            });

            // =============================
            // TAB 2 - NHÀ CUNG CẤP
            // =============================
            this.tabNhaCC.Text = "Nhà cung cấp";
            Label lblMaNCC = new Label() { Text = "Mã NCC:", Location = new System.Drawing.Point(20, 20) };
            Label lblTenNCC = new Label() { Text = "Tên NCC:", Location = new System.Drawing.Point(180, 20) };
            Label lblDiaChi = new Label() { Text = "Địa chỉ:", Location = new System.Drawing.Point(360, 20) };
            Label lblMST = new Label() { Text = "Mã số thuế:", Location = new System.Drawing.Point(560, 20) };
            Label lblTK = new Label() { Text = "Tài khoản:", Location = new System.Drawing.Point(760, 20) };
            Label lblDT = new Label() { Text = "Điện thoại:", Location = new System.Drawing.Point(30, 60) };

            txtMaNCC = new TextBox() { Location = new System.Drawing.Point(80, 20), Width = 80 };
            txtTenNCC = new TextBox() { Location = new System.Drawing.Point(250, 20), Width = 100 };
            txtDiaChi = new TextBox() { Location = new System.Drawing.Point(420, 20), Width = 120 };
            txtMST = new TextBox() { Location = new System.Drawing.Point(640, 20), Width = 100 };
            txtTK = new TextBox() { Location = new System.Drawing.Point(830, 20), Width = 100 };
            txtDT = new TextBox() { Location = new System.Drawing.Point(110, 60), Width = 150 };

            btnShowNCC = new Button() { Text = "Hiển thị", Location = new System.Drawing.Point(860, 60) };
            btnAddNCC = new Button() { Text = "Thêm", Location = new System.Drawing.Point(860, 100) };
            btnEditNCC = new Button() { Text = "Sửa", Location = new System.Drawing.Point(860, 140) };
            btnDeleteNCC = new Button() { Text = "Xóa", Location = new System.Drawing.Point(860, 180) };

            dgvNCC = new DataGridView()
            {
                Location = new System.Drawing.Point(20, 230),
                Size = new System.Drawing.Size(940, 320),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            tabNhaCC.Controls.AddRange(new Control[]
            {
                lblMaNCC, lblTenNCC, lblDiaChi, lblMST, lblTK, lblDT,
                txtMaNCC, txtTenNCC, txtDiaChi, txtMST, txtTK, txtDT,
                btnShowNCC, btnAddNCC, btnEditNCC, btnDeleteNCC, dgvNCC
            });

            // =============================
            // TAB 3 - HÀNG NHẬP
            // =============================
            this.tabHangNhap.Text = "Hàng nhập";
            Label lblMaSPHN = new Label() { Text = "Mã SP:", Location = new System.Drawing.Point(20, 20) };
            Label lblMaNCCHN = new Label() { Text = "Mã NCC:", Location = new System.Drawing.Point(180, 20) };
            Label lblSoLuong = new Label() { Text = "Số lượng:", Location = new System.Drawing.Point(340, 20) };
            Label lblDonGiaHN = new Label() { Text = "Đơn giá:", Location = new System.Drawing.Point(500, 20) };
            Label lblSoHD = new Label() { Text = "Số HĐ:", Location = new System.Drawing.Point(660, 20) };
            Label lblNgayGH = new Label() { Text = "Ngày GH:", Location = new System.Drawing.Point(820, 20) };

            txtMaSPHN = new TextBox() { Location = new System.Drawing.Point(70, 20), Width = 90 };
            txtMaNCCHN = new TextBox() { Location = new System.Drawing.Point(240, 20), Width = 90 };
            txtSL = new TextBox() { Location = new System.Drawing.Point(410, 20), Width = 80 };
            txtDGNH = new TextBox() { Location = new System.Drawing.Point(560, 20), Width = 80 };
            txtSoHD = new TextBox() { Location = new System.Drawing.Point(720, 20), Width = 80 };
            dtpNgayGH = new DateTimePicker() { Location = new System.Drawing.Point(890, 20), Width = 100 };

            btnShowHN = new Button() { Text = "Hiển thị", Location = new System.Drawing.Point(860, 60) };
            btnAddHN = new Button() { Text = "Thêm", Location = new System.Drawing.Point(860, 100) };
            btnEditHN = new Button() { Text = "Sửa", Location = new System.Drawing.Point(860, 140) };
            btnDeleteHN = new Button() { Text = "Xóa", Location = new System.Drawing.Point(860, 180) };

            dgvHN = new DataGridView()
            {
                Location = new System.Drawing.Point(20, 230),
                Size = new System.Drawing.Size(940, 320),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            tabHangNhap.Controls.AddRange(new Control[]
            {
                lblMaSPHN, lblMaNCCHN, lblSoLuong, lblDonGiaHN, lblSoHD, lblNgayGH,
                txtMaSPHN, txtMaNCCHN, txtSL, txtDGNH, txtSoHD, dtpNgayGH,
                btnShowHN, btnAddHN, btnEditHN, btnDeleteHN, dgvHN
            });

            this.ResumeLayout(false);
        }
    }
}
