﻿

CREATE TABLE tblMatHang (
    MaSP nchar(5) PRIMARY KEY,
    TenSP nvarchar(30),
    NgaySX date,
    NgayHH date,
    DonVi nvarchar(10),
    DonGia float,
    GhiChu nvarchar(200)
);
GO

CREATE TABLE tblNhaCC (
    MaNhaCC nchar(5) PRIMARY KEY,
    TenNhaCC nvarchar(50),
    DiaChi nvarchar(200),
    MaSoThue nvarchar(15),
    TaiKhoan nvarchar(15),
    DienThoai nvarchar(11)
);
GO


CREATE TABLE tblHangNhap (
    MaSP nchar(5),
    MaNhaCC nchar(5),
    SoLuong int,
    DonGia float,
    SoHD nvarchar(10),
    NgayGH date,
    PRIMARY KEY (MaSP, MaNhaCC, SoHD),
    FOREIGN KEY (MaSP) REFERENCES tblMatHang(MaSP),
    FOREIGN KEY (MaNhaCC) REFERENCES tblNhaCC(MaNhaCC)
);
GO


INSERT INTO tblNhaCC VALUES
('NCC01', N'Công ty TNHH Nguyễn Hữu', N'12 Nguyễn Trãi, Hà Nội', '0109990001', 'NH123456789', '0909123456'),
('NCC02', N'Công ty Minh Khang', N'45 Lê Lợi, Đà Nẵng', '0208880002', 'MK987654321', '0933456677'),
('NCC03', N'Công ty Hoàng Gia', N'88 Cách Mạng Tháng 8, TP.HCM', '0307770003', 'HG564738291', '0911222333');
GO

INSERT INTO tblMatHang VALUES
('SP001', N'Laptop Acer Aspire', '2023-05-10', '2026-05-10', N'Cái', 15000000, N'Bảo hành 2 năm'),
('SP002', N'Màn hình Dell 24 inch', '2023-07-01', '2026-07-01', N'Cái', 4500000, N'Màn hình LED Full HD'),
('SP003', N'Chuột Logitech M331', '2023-02-15', '2026-02-15', N'Cái', 450000, N'Chuột không dây yên tĩnh');
GO


INSERT INTO tblHangNhap VALUES
('SP001', 'NCC01', 10, 13000000, 'HD001', '2024-01-10'),
('SP002', 'NCC02', 25, 4000000, 'HD002', '2024-02-15'),
('SP003', 'NCC03', 50, 380000, 'HD003', '2024-03-01');
GO

SELECT * FROM tblNhaCC;
SELECT * FROM tblMatHang;
SELECT * FROM tblHangNhap;
GO
